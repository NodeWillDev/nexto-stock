package com.StockSave.estoque.service;
import com.StockSave.estoque.entity.Fornecedor;
import com.StockSave.estoque.repository.FornecedorRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class FornecedorService {
    private final FornecedorRepository repository;
    public FornecedorService(FornecedorRepository repository) { this.repository = repository; }
    public List<Fornecedor> listarTodos() { return repository.findAll(); }
    public Fornecedor obter(Long id) { return repository.findById(id).orElseThrow(); }
    public void salvar(Fornecedor fornecedor) { repository.save(fornecedor); }
    public void excluir(Long id) { repository.deleteById(id); }
}
