package com.StockSave.estoque.controller;
import com.StockSave.estoque.entity.Fornecedor;
import com.StockSave.estoque.service.FornecedorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/fornecedor")
public class FornecedorController {
    private final FornecedorService service;
    public FornecedorController(FornecedorService service) { this.service = service; }
    @GetMapping public String listar(Model model) { model.addAttribute("fornecedores", service.listarTodos()); return "fornecedor/lista"; }
    @GetMapping("/criar") public String criar(Model model) { model.addAttribute("fornecedor", new Fornecedor()); return "fornecedor/formulario"; }
    @PostMapping("/salvar") public String salvar(@ModelAttribute Fornecedor fornecedor) { service.salvar(fornecedor); return "redirect:/fornecedor"; }
    @GetMapping("/editar/{id}") public String editar(@PathVariable Long id, Model model) { model.addAttribute("fornecedor", service.obter(id)); return "fornecedor/formulario"; }
    @PostMapping("/excluir/{id}") public String excluir(@PathVariable Long id) { service.excluir(id); return "redirect:/fornecedor"; }
}
