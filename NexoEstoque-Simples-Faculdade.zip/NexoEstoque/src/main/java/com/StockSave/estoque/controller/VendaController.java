package com.StockSave.estoque.controller;

import com.StockSave.estoque.dto.CriarVendaRequest;
import com.StockSave.estoque.dto.EditarVendaRequest;
import com.StockSave.estoque.service.VendaService;
import com.StockSave.estoque.service.ClienteService;
import com.StockSave.estoque.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/venda")
public class VendaController {
    private final VendaService service;
    private final ClienteService clienteService;
    private final ProdutoService produtoService;

    public VendaController(VendaService service, ClienteService clienteService, ProdutoService produtoService){
        this.service = service;
        this.clienteService = clienteService;
        this.produtoService = produtoService;
    }

    @GetMapping
    public ModelAndView index(){
        var mv = new ModelAndView("/venda/listagem_de_vendas");
        var lista = service.listarTodos();
        mv.addObject("vendas", lista);
        return mv;
    }

    @GetMapping("/criar")
    public ModelAndView criar() {
        var mv = new ModelAndView("venda/cadastro_venda");
        mv.addObject("clientes", clienteService.listarTodos());
        mv.addObject("produtos", produtoService.listarTodos());
        mv.addObject("criarVendaRequest", new CriarVendaRequest(null, null, null,1, null, null,null, false, 0, 0, null, null));
        return mv;
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute CriarVendaRequest request) {
        ModelAndView mv;
        try {
            var venda = service.criar(request);
            return new ModelAndView("redirect:/venda");
        } catch (Exception e) {
            mv = new ModelAndView("venda/cadastro_venda");
            mv.addObject("clientes", clienteService.listarTodos());
            mv.addObject("produtos", produtoService.listarTodos());
            mv.addObject("criarVendaRequest", request);
            mv.addObject("erro", e.getMessage());
            return mv;
        }
    }

    @GetMapping("/{id}")
    public String visualizar(@PathVariable("id") Long id) {
        return "redirect:/venda/editar/" + id;
    }

    @GetMapping("/editar/{id}")
    public ModelAndView editar(@PathVariable("id") Long id) {
        var optional = service.obterPeloId(id);
        var mv = new ModelAndView("venda/editar_venda");
        var venda = optional.get();
        var request = new EditarVendaRequest(venda.getId(), venda.getCliente().getId(), venda.getProduto().getId(), venda.getQuantidade(), venda.getData(), venda.getDesconto(), venda.getTotal(), venda.isParcelado(), venda.getQtdParcelas(), venda.getQtdPagas(), venda.getStatusPagamento(), venda.getStatusEntrega());
        mv.addObject("clientes", clienteService.listarTodos());
        mv.addObject("produtos", produtoService.listarTodos());
        mv.addObject("editarVendaRequest", request);
        return mv;
    }

    @PostMapping("/editar")
    public ModelAndView editar(@ModelAttribute EditarVendaRequest request) {
        ModelAndView mv;
        try {
            var venda = service.editar(request);
            return new ModelAndView("redirect:/venda");
        } catch (Exception e) {
            mv = new ModelAndView("venda/editar_venda");
            mv.addObject("clientes", clienteService.listarTodos());
            mv.addObject("produtos", produtoService.listarTodos());
            mv.addObject("editarVendaRequest", request);
            mv.addObject("erro", e.getMessage());
            return mv;
        }
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable("id") Long id){
        service.deletarPeloId(id);
        return "redirect:/venda";
    }
}
