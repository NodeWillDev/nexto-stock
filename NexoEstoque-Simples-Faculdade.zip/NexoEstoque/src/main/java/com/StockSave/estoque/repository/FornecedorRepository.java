package com.StockSave.estoque.repository;
import com.StockSave.estoque.entity.Fornecedor;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {}
