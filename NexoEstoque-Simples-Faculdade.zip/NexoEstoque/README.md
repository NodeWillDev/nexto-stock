# NexoEstoque — Sistema WEB (Projeto de faculdade)

**Tema:** sistema simples de controle de estoque e vendas de camisetas esportivas.

## Funcionalidades
- Produtos: cadastrar, listar, editar e excluir.
- Clientes: cadastrar, listar, editar e excluir.
- Vendas: cadastrar, listar, editar e excluir (com cliente e produto).
- Fornecedores: cadastrar, listar, editar e excluir.

## Tecnologias e arquitetura
- Java 17, Spring Boot, Spring MVC, Spring Data JPA, Thymeleaf, HTML/CSS, H2 (banco relacional).
- **Model**: `entity/` (4 entidades), `repository/` e `service/`.
- **Control**: `controller/` (usa somente Service, sem acessar Repository diretamente).
- **View**: `src/main/resources/templates/` e `static/css/style.css`.

## Executar
1. Instale Java 17 ou superior.
2. No terminal da pasta do projeto execute `./mvnw spring-boot:run` (Linux/Mac) ou `mvnw.cmd spring-boot:run` (Windows).
3. Acesse http://localhost:8080.
4. Banco H2 persistente no arquivo `data/estoque.mv.db` criado ao iniciar.

## Protótipos de telas (HTML do próprio projeto)
- [Tela inicial](src/main/resources/templates/index.html)
- [Produtos](src/main/resources/templates/produto/listagem_de_produtos.html)
- [Cadastro de produtos](src/main/resources/templates/produto/cadastro_produto.html)
- [Clientes](src/main/resources/templates/cliente/listagem_de_clientes.html)
- [Vendas](src/main/resources/templates/venda/listagem_de_vendas.html)
- [Fornecedores](src/main/resources/templates/fornecedor/lista.html)
- [Cadastro de fornecedores](src/main/resources/templates/fornecedor/formulario.html)

## Diagrama de classes
```mermaid
classDiagram
class Cliente {
  Long id
  String nome
  String telefone
  String email
  String endereco
}
class Produto {
  Long id
  String sku
  String modelo
  String time
  String tamanho
  BigDecimal valor
  int quantidade
}
class Venda {
  Long id
  int quantidade
  LocalDate data
  BigDecimal desconto
  BigDecimal total
  boolean parcelado
  String statusPagamento
  String statusEntrega
}
class Fornecedor {
  Long id
  String nome
  String telefone
  String email
}
Cliente "1" --> "0..*" Venda
Produto "1" --> "0..*" Venda
```

## Diagrama MER (entidade-relacionamento)
```mermaid
erDiagram
  CLIENTE ||--o{ VENDA : realiza
  PRODUTO ||--o{ VENDA : vendido_em
  CLIENTE { bigint id PK
    varchar nome
    varchar telefone
    varchar email
    varchar endereco }
  PRODUTO { bigint id PK
    varchar sku
    varchar modelo
    varchar time
    varchar tamanho
    decimal valor
    int quantidade }
  VENDA { bigint id PK
    bigint cliente_id FK
    bigint produto_id FK
    int quantidade
    date data
    decimal total }
  FORNECEDOR { bigint id PK
    varchar nome
    varchar telefone
    varchar email }
```

**Observação:** Fornecedor é um cadastro independente para cumprir o requisito de quatro tabelas; não há vínculo com produtos nesta versão simples.

## Publicação no GitHub
Crie um repositório na sua conta, envie estes arquivos e coloque o link do repositório na entrega. O link não é incluído porque o repositório não foi publicado automaticamente.
